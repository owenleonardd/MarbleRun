この商品をダウンロードしていただきありがとうございます。

私は、最良の使用のために手のアーマチュア内の人差し指の骨の最初の部分にアイスキャンディーを取り付けることをお勧めします（指が手の残りの部分に接続され、先端ではなく、指が接続されている場所）。


質問や懸念事項については、daviddd5438@gmail.com で私に電子メールを送るか、Discord David#4816 で私を追加します。


Thank you for downloading this product!

I recommend attaching the popsicle to the first part of the index finger bone within the hand armature for best use (where the finger attaches to the rest of the hand, not the tip).


For questions or concerns, email me at daviddd5438@gmail.com or add me on Discord David#4816